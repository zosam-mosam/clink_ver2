import React from "react";

const Header = () => {
  return (
    <div className="Header" style={{ width: "100%", height: "50px" }}></div>
  );
};

export default Header;
