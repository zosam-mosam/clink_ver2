const MainHello = ({ name }) => {
  return <div className="main-hello">저축 초보자 {name}님 안녕하세요 !</div>;
};

export default MainHello;
