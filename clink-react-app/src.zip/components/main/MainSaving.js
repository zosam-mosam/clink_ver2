import { Component } from "react";

class MainSaving extends Component {
  render(props) {
    return;
  }
}

export default MainSaving;
