import React from "react";

const ChallengeTitle = () => {
  return (
    <div className="ChallengeTitle">
      <div id="ChallengeTitle">하루 만원 챌린지 도전!!</div>
      <div id="ChallengeDescription">"개같이 벌어서 정승같이 쓰자"</div>
    </div>
  );
};

export default ChallengeTitle;
