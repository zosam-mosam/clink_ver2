import React from "react";

const Bottom = () => {
  return (
    <div className="Header" style={{ width: "100%", height: "50px" }}></div>
  );
};

export default Bottom;
