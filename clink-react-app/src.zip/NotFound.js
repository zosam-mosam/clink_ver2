import './NotFound.css';
function NotFound() {
  return (
    <div className="notFound">
      <h1>페이지를 찾을 수 없습니다. NotFound</h1>
    </div>
  );
}
export default NotFound;
